<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class AuthCLIController extends Controller
{
    //
}
