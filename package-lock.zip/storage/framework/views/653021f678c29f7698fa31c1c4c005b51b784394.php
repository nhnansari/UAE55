<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">

<head>

    <title><?php echo $__env->yieldContent('title'); ?></title>

    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="generator" content="Naeem Hassan" />
    <meta charset="UTF-8" />
    <meta http-equiv="x-dns-prefetch-control" content="on" />
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1, maximum-scale=1" />

    <meta name="description" content="" />
    <meta name="Keywords" content="" />

    <link rel="stylesheet" href="/assets/css/style.css" />
    <link rel="shortcut icon" href="/favicon.ico" type="image/x-icon">

    <link rel="stylesheet" type="text/css" href="/assets/css/MegaNavbar.css" />
    <link rel="stylesheet" type="text/css" href="/assets/css/navbar-default.css" title="inverse">
    <link rel="stylesheet" type="text/css" href="/assets/css/animation.css" title="inverse">

    <script src="/assets/js/jquery.js"></script>
    <script src="/libs/javascript/system.lib.js"></script>
    <script src="/assets/js/jquery.ui.js"></script>
    <script src="/assets/js/ui.datepicker-en.js"></script>

    <script src="/assets/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="/assets/css/bootstrap.css">
    <link rel="stylesheet" href="/assets/css/font-awesome.css">
    <link href="https://fonts.googleapis.com/css?family=Cairo:400,600,700&amp;subset=arabic" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css" integrity="sha512-MV7K8+y+gLIBoVD59lQIYicR65iaqukzvf/nwasF0nqhPay5w/9lJmVM2hMDcnK1OnMGCdVK+iQrJ7lzPJQd1w==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <!-- Twitter Card data -->
    <meta name="twitter:card" content="summary">
    <meta name="twitter:title" content="Distinctive Car Numbers">

    <!-- Open Graph data -->
    <meta property="og:title" content="Distinctive Car Numbers" />
    <meta property="og:type" content="website" />
    <meta property="og:url" content="/en/vip-numbers/distinctive-uae-car-numbers/index2.html" />
    <meta property="og:site_name" content="UAE55.Com" />

    <script type="text/javascript">
        var rlLangDir = 'ltr';
        var rlLang = 'en';
        var isLogin = false;
        var staticDataClass = true;

        var rlPageInfo = new Array();
        rlPageInfo['key'] = 'lt_vip_numbers';
        rlPageInfo['controller'] = 'listing_type';
        rlPageInfo['path'] = 'vip-numbers';

        var rlConfig = new Array();
        var rlAccountInfo = new Array();
        rlAccountInfo['ID'] = null;

        flynax.langSelector();
    </script>
    <script src="/assets/js/lib.js"></script>
</head>

<body class="large lt-vip-numbers-page bc-exists">
<div class="main-wrapper">

    <?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- page content -->

        <?php echo $__env->yieldContent('content'); ?>
    <!-- page content end -->
  <?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


</div>

<div id="login_modal_source" class="hide">
    <div class="tmp-dom">
        <div class="caption_padding">Sign in</div>
        <form action="/en/login.html" method="post">
            <input type="hidden" name="action" value="login" />

            <div class="submit-cell">
                <div class="name">Username</div>
                <div class="field">
                    <input type="text" name="username" maxlength="35" value="" />
                </div>
            </div>
            <div class="submit-cell">
                <div class="name">Password</div>
                <div class="field">
                    <input type="password" name="password" maxlength="35" />
                </div>
            </div>

            <div class="submit-cell buttons">
                <div class="name"></div>
                <div class="field">
                    <input type="submit" value="Sign in" />

                    <div style="padding: 10px 0 0 0;">Forgot your password? <a title="Reset your password" class="brown_12" href="/en/reset-password.html">Remind</a></div>
                </div>
            </div>
        </form>
    </div>
</div>

<link rel="stylesheet" href="/templates/general_wide_rakmoon/css/jquery.ui.css" />
<link rel="stylesheet" href="/plugins/categories_tree/static/style.css" />

<script src="/templates/general_wide_rakmoon/js/util.js"></script>
<script src="/plugins/autoPoster/static/lib.js"></script>
<script src="//maps.googleapis.com/maps/api/js?libraries=places&language=en&key="></script>
<script>
    flUtil.init();
</script>

</body>

</html>
<?php /**PATH D:\WorkProjects\PHP\UAE55\resources\views/layout/layout.blade.php ENDPATH**/ ?>