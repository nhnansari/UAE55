<?php if(auth()->guard()->guest()): ?>
    <p>Crafted with <span class="text-danger">♥</span> by Alexandr Chernyaev</p>
<?php else: ?>

    <div class="text-center user-select-none">
        <p class="small m-0">
            <?php echo e(__('The application code is published under the MIT license.'), false); ?> 2016 - <?php echo e(date('Y'), false); ?><br>
            <a href="http://orchid.software" target="_blank" rel="noopener">
                <?php echo e(__('Version'), false); ?>: <?php echo e(\Orchid\Platform\Dashboard::VERSION, false); ?>

            </a>
        </p>
    </div>
<?php endif; ?>
<?php /**PATH D:\WorkProjects\PHP\UAE55\vendor\orchid\platform\resources\views/footer.blade.php ENDPATH**/ ?>