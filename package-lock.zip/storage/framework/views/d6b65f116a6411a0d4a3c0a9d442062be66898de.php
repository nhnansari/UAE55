<?php $__env->startSection('title','Distinctive Numbers'); ?>
<?php $__env->startSection('content'); ?>
    <!-- ======= Team Section ======= -->
    <section id="team" class="team section-bg">
        <div class="container">
            <div class="section-title">
                <h2>Your Favorites</h2>
                <p>Here is the stuff you loved at UAE55</p>
            </div>

            <div class="row">
                <div class="col-sm-12 col-lg-12 col-xl-12">
                    <div class="row">
                        <?php $__currentLoopData = $favorites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $favorite): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <div class="col-lg-4 col-md-6 d-flex align-items-stretch">
                                <div class="member">
                                    <div class="member-img">
                                        <img src="/rendered/<?php echo e($favorite->picture, false); ?>" class="img-fluid" alt="">

                                    </div>


                                    <div class="member-info">
                                        <a href="<?php echo e(route('number',['ad'=>$favorite->slug]), false); ?>">  <h4><?php echo e($favorite->title, false); ?></h4> </a>
                                        <span><?php echo e($favorite->description, false); ?></span>
                                    </div>
                                    <div class="member-info">
                                        <div class="row">
                                            <div class="col-6">
                                                <h4><?php echo e($favorite->price, false); ?> AED</h4>
                                            </div>
                                            <div class="col-6">
                                                <h4><?php echo e($favorite->ad_date, false); ?></h4>
                                            </div>
                                        </div>

                                    </div>
                                    <div class="row">
                                        <div class="col-6 col-sm-12 col-lg-6 col-xl-6 p-2 text-center">
                                            <a href="<?php echo e(route('number',['ad'=>$favorite->slug]), false); ?>"><button class="btn btn-primary">Details</button></a>
                                        </div>
                                        <div class="col-6 col-sm-12 col-lg-6 col-xl-6 text-right p-2">
                                            <button class="btn btn-danger" onclick="removeFavorite(<?php echo e($favorite->id, false); ?>)">Remove <i class="bi bi-trash" title="Remove from Favorites"></i></button>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="row">
                        <?php echo e($favorites->links('pagination::bootstrap-4'), false); ?>

                    </div>
                </div>
            </div>



        </div>
    </section><!-- End Team Section -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('theme1.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WorkProjects\PHP\UAE55\resources\views/theme1/favorites.blade.php ENDPATH**/ ?>