<div class="dropdown-item">
    <div class="form-check h-auto w-100 d-flex align-items-center ps-0">
        <input type="checkbox"
               checked
               class="custom-control-input"
               id="<?php echo e($slug, false); ?>"
               form="table-columns-select"
               data-action="table#toggleColumn"
               data-default-hidden="<?php echo e($defaultHidden, false); ?>"
               data-column="<?php echo e($slug, false); ?>"
        >
        <label class="form-check-label d-block w-100 cursor ms-2 user-select-none" for="<?php echo e($slug, false); ?>">
            <?php echo e($title, false); ?>

        </label>
    </div>
</div>
<?php /**PATH D:\WorkProjects\PHP\UAE55\vendor\orchid\platform\resources\views/partials/layouts/selectedTd.blade.php ENDPATH**/ ?>