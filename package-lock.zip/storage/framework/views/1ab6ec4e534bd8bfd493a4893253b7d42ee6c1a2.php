<?php $__env->startSection('title','Distinctive Numbers'); ?>
<?php $__env->startSection('content'); ?>
    <!-- ======= Team Section ======= -->
    <section id="team" class="team section-bg">
        <div class="container">
            <div class="section-title">
                <h2>Dashboard</h2>
            </div>

            <div class="row">
                <div class="col-sm-12 col-lg-12 col-xl-12 card p-3">
                     <div class="row mb-4">
                        <div class="col-sm-6 col-lg-3 col-xl-3  text-center ">
                            <a class="btn btn-primary" href="<?php echo e(route('paint'), false); ?>">Paint License Plate</a>
                        </div>
                        <div class="col-sm-6 col-lg-3 col-xl-3  text-center ">
                            <a class="btn btn-primary" href="<?php echo e(route('new_ad'), false); ?>">Post New Ad</a>
                        </div>
                    </div>
                    <hr/>
                    <div class="row">

                        <div class="col-sm-12 col-lg-4 col-xl-4 card text-center p-2">
                            <h3>Plate Number Ads</h3>
                            <table class="table">
                                <tr>
                                    <td>Total</td><td><?php echo e($counts["license_plate_total"], false); ?></td>
                                </tr>
                                <tr>
                                    <td>Pending</td><td><?php echo e($counts["license_plate_pending"], false); ?></td>
                                </tr>
                                <tr>
                                    <td>Approved</td><td><?php echo e($counts["license_plate_approved"], false); ?></td>
                                </tr>
                                <tr>
                                    <td>Sold</td><td><?php echo e($counts["license_plate_sold"], false); ?></td>
                                </tr>
                            </table>

                            <a class="" href="<?php echo e(route('my_ads'), false); ?>">View All</a>
                        </div>
                        <div class="col-sm-12 col-lg-4 col-xl-4 card text-center">
                            <h3>Vehicle Ads</h3>
                            <h5>5</h5>
                            <button class="btn btn-primary">Post New Ad</button>
                        </div>
                        <div class="col-sm-12 col-lg-4 col-xl-4 card text-center">
                            <h3>Property Ads</h3>
                            <h5>5</h5>
                            <button class="btn btn-primary">Post New Ad</button>
                        </div>
                        <div class="col-sm-12 col-lg-4 col-xl-4 card text-center">
                            <h3>Vacancy Ads</h3>
                            <h5>5</h5>
                            <button class="btn btn-primary">Post New Ad</button>
                        </div>
                    </div>

                </div>
            </div>



        </div>
    </section><!-- End Team Section -->

<?php $__env->stopSection(); ?>
<script>
    import Index from "../../../public/theme1/vendor/bootstrap-icons/index.html";
    export default {
        components: {Index}
    }
</script>

<?php echo $__env->make('theme1.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WorkProjects\PHP\UAE55\resources\views/theme1/dashboard.blade.php ENDPATH**/ ?>