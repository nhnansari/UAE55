<?php $__env->startComponent($typeForm, get_defined_vars()); ?>
    <div data-controller="input"
         data-input-mask="<?php echo e($mask ?? '', false); ?>"
    >
        <input <?php echo e($attributes, false); ?>>
    </div>

    <?php if(empty(!$datalist)): ?>
        <datalist id="datalist-<?php echo e($name, false); ?>">
            <?php $__currentLoopData = $datalist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($item, false); ?>">
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </datalist>
    <?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH D:\WorkProjects\PHP\UAE55\vendor\orchid\platform\resources\views/fields/input.blade.php ENDPATH**/ ?>