<?php $__env->startPush('modals-container'); ?>
    <div class="modal fade center-scale"
         id="screen-modal-<?php echo e($key, false); ?>"
         role="dialog"
         aria-labelledby="screen-modal-<?php echo e($key, false); ?>"
         data-controller="modal"
         data-modal-slug="<?php echo e($templateSlug, false); ?>"
         data-modal-async-enable="<?php echo e($asyncEnable, false); ?>"
         data-modal-async-route="<?php echo e($asyncRoute, false); ?>"
         data-modal-open="<?php echo e($open, false); ?>"
        <?php echo e($staticBackdrop ? "data-bs-backdrop=static" : '', false); ?>

    >
        <div class="modal-dialog modal-fullscreen-md-down <?php echo e($size, false); ?> <?php echo e($type, false); ?>" role="document" id="screen-modal-type-<?php echo e($key, false); ?>">
            <form class="modal-content"
                  id="screen-modal-form-<?php echo e($key, false); ?>"
                  method="post"
                  enctype="multipart/form-data"
                  data-controller="form"
                  data-action="form#submit"
                  data-form-button-animate="#submit-modal-<?php echo e($key, false); ?>"
                  data-form-button-text="<?php echo e(__('Loading...'), false); ?>"
            >
                <div class="modal-header">
                    <h4 class="modal-title text-black fw-light" data-modal-target="title"><?php echo e($title, false); ?></h4>
                    <button type="button" class="btn-close" title="Close" data-bs-dismiss="modal" aria-label="Close">
                    </button>
                </div>
                <div class="modal-body layout-wrapper">
                    <div data-async>
                        <?php $__currentLoopData = $manyForms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $formKey => $modal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $__currentLoopData = $modal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo $item ?? ''; ?>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                    <?php echo csrf_field(); ?>
                </div>
                <div class="modal-footer">

                    <?php if(!$withoutCloseButton): ?>
                        <button type="button" class="btn btn-link" data-bs-dismiss="modal">
                            <?php echo e($close, false); ?>

                        </button>
                    <?php endif; ?>

                    <?php if(empty($commandBar)): ?>
                        <?php if(!$withoutApplyButton): ?>
                            <button type="submit"
                                    id="submit-modal-<?php echo e($key, false); ?>"
                                    data-turbo="<?php echo e(var_export($turbo), false); ?>"
                                    class="btn btn-default">
                                <?php echo e($apply, false); ?>

                            </button>
                        <?php endif; ?>
                    <?php else: ?>
                        <?php echo $commandBar; ?>

                    <?php endif; ?>

                </div>
            </form>
        </div>
    </div>
<?php $__env->stopPush(); ?>
<?php /**PATH D:\WorkProjects\PHP\UAE55\vendor\orchid\platform\resources\views/layouts/modal.blade.php ENDPATH**/ ?>