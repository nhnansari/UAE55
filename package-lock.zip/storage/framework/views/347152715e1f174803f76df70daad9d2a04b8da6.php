<div class="form-group mb-0">

    <?php if(isset($title)): ?>
        <label for="<?php echo e($id, false); ?>" class="form-label mb-0">
            <?php echo e($title, false); ?>

        </label>
    <?php endif; ?>

    <?php echo e($slot, false); ?>


    <?php if($errors->has($oldName)): ?>
        <div class="invalid-feedback d-block">
            <small><?php echo e($errors->first($oldName), false); ?></small>
        </div>
    <?php elseif(isset($help)): ?>
        <small class="form-text text-muted"><?php echo $help; ?></small>
    <?php endif; ?>
</div>
<?php /**PATH D:\WorkProjects\PHP\UAE55\vendor\orchid\platform\resources\views/partials/fields/clear.blade.php ENDPATH**/ ?>