<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32" width="0.5em" height="0.5em" role="img" fill="currentColor" path="circle" componentName="orchid-icon">
    <circle cx="16" cy="16" r="16"></circle>
</svg>
<?php /**PATH D:\WorkProjects\PHP\UAE55\storage\framework\views/44dcab26394fc955faa0a1b85a883fa870ceda77.blade.php ENDPATH**/ ?>