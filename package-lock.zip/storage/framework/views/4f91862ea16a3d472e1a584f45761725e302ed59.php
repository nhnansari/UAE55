<?php $__currentLoopData = $generate(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $crumbs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($crumbs->url() && !$loop->last): ?>
        <li class="<?php echo e($class, false); ?>">
            <a href="<?php echo e($crumbs->url(), false); ?>"><?php echo e($crumbs->title(), false); ?></a>
        </li>
    <?php else: ?>
        <li class="<?php echo e($class, false); ?> <?php echo e($active, false); ?>"><?php echo e($crumbs->title(), false); ?></li>
    <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH D:\WorkProjects\PHP\UAE55\vendor\tabuna\breadcrumbs\src/../views/breadcrumbs.blade.php ENDPATH**/ ?>