<?php $__env->startSection('title','Distinctive Numbers'); ?>
<?php $__env->startSection('content'); ?>
    <!-- ======= Team Section ======= -->
    <section id="team" class="team section-bg">
        <div class="container">
            <div class="section-title">
                <h2>Distinctive Numbers</h2>
                <p>Find a cool license number for you.</p>
            </div>

            <div class="row">
                <div class="col-sm-12 col-lg-3 col-xl-3">
                    <h4>Filter</h4>
                    <form action="">
                        <div class="form-group">
                            <label for="formGroupExampleInput">Price</label>
                            <div class="row">
                                <div class="col-6">
                                    <input type="number" name="price_min" class="form-control" id="formGroupExampleInput" placeholder="0">
                                </div>
                                <div class="col-6">
                                    <input type="number" name="price_max" class="form-control" id="formGroupExampleInput" placeholder="0">
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="formGroupExampleInput2">Emirates</label>
                            <select type="text" class="form-control" name="emirates">
                                <option value="">- Any -</option>
                                <option value="Abu Dhabi">Abu Dhabi</option>
                                <option value="Dubai">Dubai</option>
                                <option value="Sharjah">Sharjah</option>
                                <option value="Ajman">Ajman</option>
                                <option value="Ras Al Khaimah">Ras Al Khaimah</option>
                                <option value="Fujairah">Fujairah</option>
                                <option value="Umm Al Quawain">Umm Al Quawain</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="formGroupExampleInput2">Sold</label>
                            <select type="text" class="form-control" name="sold">
                                <option value="unsold">Unsold</option>
                                <option value="sold">Sold</option>
                            </select>
                        </div>
                        <input type="submit" value="search" class="btn btn-primary">
                    </form>
                </div>
                <div class="col-sm-12 col-lg-9 col-xl-9">
                    <div class="row">
                        <?php $__currentLoopData = $ads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-lg-4 col-md-6 d-flex align-items-stretch">
                                <div class="member">
                                    <div class="member-img">
                                        <img src="/rendered/<?php echo e($ad->picture, false); ?>" class="img-fluid" alt="">
                                        <div class="social">
                                            <?php if(auth()->guard()->check()): ?>
                                            <?php if(!$ad->isFavorite): ?>
                                            <a href="#"  onclick="addFavorite(<?php echo e($ad->id, false); ?>)" class="prevent"><i class="bi bi-heart" title="Add to Favorite"></i></a>
                                            <?php endif; ?>
                                            <a href="#"  class="prevent"><i class="bi bi-hammer" title="Place a bid"></i></a>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="member-info">
                                        <a href="<?php echo e(route('number',['ad'=>$ad->slug]), false); ?>">  <h4><?php echo e($ad->title, false); ?></h4> </a>
                                        <span><?php echo e($ad->description, false); ?></span>
                                    </div>
                                    <div class="row text-center">
                                        <h5><?php echo e($ad->price, false); ?> AED</h5>
                                    </div>
                                    <div class="row">
                                        <div class="col-4 col-sm-12 col-lg-4 col-xl-4 p-2 text-center">
                                            <a href="<?php echo e(route('number',['ad'=>$ad->slug]), false); ?>"><button class="btn btn-primary">Details</button></a>
                                        </div>
                                        <div class="col-8 col-sm-12 col-lg-8 col-xl-8 text-right p-2">
                                            <?php if(auth()->guard()->check()): ?>
                                                <?php if(!$ad->isFavorite): ?>
                                                    <button class="btn btn-primary" onclick="addFavorite(<?php echo e($ad->id, false); ?>)">Make Favorite <i class="bi bi-heart" title="Add to Favorite"></i></button>
                                                <?php endif; ?>
                                             <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="row">
                        <?php echo e($ads->links('pagination::bootstrap-4'), false); ?>

                    </div>
                </div>
            </div>



        </div>
    </section><!-- End Team Section -->

<?php $__env->stopSection(); ?>


<?php echo $__env->make('theme1.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WorkProjects\PHP\UAE55\resources\views/theme1/ads.blade.php ENDPATH**/ ?>