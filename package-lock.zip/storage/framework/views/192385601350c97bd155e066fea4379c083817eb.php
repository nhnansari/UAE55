<?php $__env->startSection('title','Paint License Plate'); ?>
<?php $__env->startSection('content'); ?>
    <!-- ======= Team Section ======= -->
    <section id="team" class="team section-bg">
        <div class="container">
            <div class="section-title">
                <h2>Paint a License Plate</h2>
                <p> </p>
            </div>

            <div class="row card">
                <div class="col-sm-12 col-lg-12 col-xl-12">
                     <?php echo $__env->make('common.new_ad', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>



        </div>
    </section><!-- End Team Section -->

<?php $__env->stopSection(); ?>


<?php echo $__env->make('theme1.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WorkProjects\PHP\UAE55\resources\views/theme1/newad/plate.blade.php ENDPATH**/ ?>