<td class="text-<?php echo e($align, false); ?> <?php if(!$width): ?> text-truncate <?php endif; ?>"
    data-column="<?php echo e($slug, false); ?>" colspan="<?php echo e($colspan, false); ?>"
    <?php if(empty(!$width)): ?>style="min-width:<?php echo e(is_numeric($width) ? $width . 'px' : $width, false); ?>;"<?php endif; ?>
>
    <div>
        <?php if(isset($render)): ?>
            <?php echo $value; ?>

        <?php else: ?>
            <?php echo e($value, false); ?>

        <?php endif; ?>
    </div>
</td>
<?php /**PATH D:\WorkProjects\PHP\UAE55\vendor\orchid\platform\resources\views/partials/layouts/td.blade.php ENDPATH**/ ?>